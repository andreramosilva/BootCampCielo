package com.example.precadastro.PreCadastro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PreCadastroApplication {

	public static void main(String[] args) {
		SpringApplication.run(PreCadastroApplication.class, args);
	}

}
